from pathlib import Path
import numpy as np, json,struct,copy
from scipy.ndimage import gaussian_filter,map_coordinates
from scipy.interpolate import PchipInterpolator,RegularGridInterpolator
from scipy.spatial import cKDTree
D=Path(__file__).parent;S=D;tab='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
rows=(D/'scan_rings.txt').read_text().splitlines();A=np.array([np.interp(np.arange(80)/80,np.arange(len(r))/len(r),[tab.index(c)/63*3.5 for c in r],period=1) for r in rows]);A=gaussian_filter(A,(.95,.9),mode=('nearest','wrap')); mirror=A[:,(-np.arange(80))%80]; A=.72*A+.28*mirror; sym=.35*np.exp(-((np.arange(65)-24)/6)**4)[:,None]; A=A*(1-sym)+A[:,(-np.arange(80))%80]*sym
# Use the complete radial cross sections, rather than blending a frontal depth map onto an oval.
# Scale to the same world coordinate system as V22 and its head joint.
R0=np.unique(np.r_[np.linspace(0,64,241),np.linspace(19,30,181)]);ang=np.unique(np.r_[np.linspace(-np.pi,np.pi,321),np.linspace(-.85,.85,181)]);rr,t=np.meshgrid(R0,ang,indexing='ij');Ap=np.pad(A,((3,3),(3,3)),mode='wrap');Ap[:3]=Ap[3];Ap[-3:]=Ap[-4];rho=map_coordinates(Ap,[rr+3,(t+np.pi)/(2*np.pi)*80+3],order=3,mode='nearest')*.051
x=rho*np.sin(t);y=1.84-rr*(6.2/64)*.051;z=rho*np.cos(t)-.008
# Correct apex to a smooth cap, away from the measurement origin.
cap=np.sqrt(np.clip(rr/2.4,0,1));bc=np.clip((2.4-rr)/2.4,0,1);bc=bc*bc*(3-2*bc)
x=x*(1-bc)+.033*cap*np.sin(t)*bc
z=z*(1-bc)+(-.008+.038*cap*np.cos(t))*bc
# Smooth measurement quantization in neck, retain the sagittal shape.
neck=np.clip((rr-47)/11,0,1);smooth=gaussian_filter(rho,(4.0,3.5),mode=('nearest','wrap'));x=x*(1-neck)+smooth*np.sin(t)*neck;z=z*(1-neck)+(smooth*np.cos(t)-.008)*neck
# Add subtle age-related jowl and cheek contours, while retaining scanned skull proportions.
front=np.maximum(np.cos(t),0);g=lambda xx,yy,sx,sy:np.exp(-((x-xx)/sx)**2-((y-yy)/sy)**2)
for side in [-1,1]:
 z+=front**3*(.0050*g(side*.044,1.685,.022,.018)+.0033*g(side*.043,1.638,.022,.019)-.0028*g(side*.065,1.718,.018,.025))
 # cheek crease and nasolabial folds
 curve=side*(.020+.62*(1.691-y));z-=front**3*.0015*np.exp(-((x-curve)/.0045)**2-((y-1.658)/.022)**2)
# subtle forehead grooves, without texture
for i,yy in enumerate([1.774,1.786,1.798]):z-=front**4*.0008*np.exp(-((y-yy-.002*np.cos(x*42+i))/.0017)**2-(x/.058)**4)
# Sculpt closed lips and age folds on the scan reconstruction.
arch=1.653+.00075*np.cos(np.pi*x/.026)-.0007*np.exp(-(x/.0055)**2)+.00045*np.sin(x*90)
env=np.exp(-(x/.026)**6)*front**5
z+=env*(.0024*np.exp(-((y-arch-.003)/.0036)**2)+.0029*np.exp(-((y-arch+.0037)/.0045)**2)-.0026*np.exp(-((y-arch)/.0010)**2))
z-=.0018*g(0,1.671,.004,.008)*front**4
for side in [-1,1]:
 z-=.0028*g(side*.011,1.684,.0042,.0030)*front**5
 z+=.0021*g(side*.0135,1.689,.007,.005)*front**4
 z-=.0016*g(side*.026,1.652,.004,.005)*front**4
# Ear relief on the contiguous scan shell, no separate disk-like ear.
for side in [-1,1]:
 ey=y-1.696;ez=z+.009;er=np.sqrt((ey/.025)**2+(ez/.014)**2)
 region=np.clip((side*x-.069)/.016,0,1)*np.exp(-((ey/.032)**6+(ez/.024)**6))
 x+=side*region*(.0030*np.exp(-((er-.76)/.17)**2)-.0036*np.exp(-((ey-.001)/.013)**2-((ez-.003)/.007)**2)+.0018*np.exp(-((ey+.009)/.006)**2-((ez-.010)/.005)**2))
# Continuous orbital soft tissue and almond-shaped eyelids.
EX=.0345; EY=1.725; R=.0122; centers=[]
for side in [-1,1]:
 cx=side*EX;cy=EY+side*.0005;cz=.0732;centers.append((cx,cy,cz))
 dx=x-cx;dy=y-cy
 z+=front**4*(.0017*g(cx,cy+.013,.018,.0065)+.0013*g(cx,cy-.010,.017,.007))
 z-=front**4*.0012*g(cx,cy+.0067,.017,.0034)
 arc=np.sqrt(np.maximum(0,1-(dx/.0115)**2));cl=-side*.065*dx
 upper=.0051*arc+cl;lower=-.0041*arc+cl
 radius2=dx*dx+dy*dy;sf=cz+np.sqrt(np.maximum(0,R*R-radius2))
 dist=np.maximum(np.maximum(dy-upper,lower-dy),np.abs(dx)-.0115)
 blend=np.clip((.025-np.sqrt(dx*dx+(dy*.93)**2))/.010,0,1)*np.clip(front/.7,0,1);blend=blend*blend*(3-2*blend)
 ramp=np.clip((dist+.00065)/.0013,0,1);ramp=ramp*ramp*(3-2*ramp)
 desired=sf-.0026+.0031*ramp+.00045*np.exp(-((dist-.0017)/.0015)**2)*ramp
 outside=np.maximum(z,desired);target=np.where(dist<.0012,desired,outside)
 z=z*(1-blend)+target*blend
 cover=(radius2<R*R)&(dist>.0007)&(front>.6);z=np.where(cover,np.maximum(z,sf+.00025),z)
# Nasal wings and soft tissue around the nostrils.
z+=front**5*(.0030*g(0,1.690,.012,.008)+.0017*g(0,1.705,.010,.015))
for side in [-1,1]:
 z+=front**5*.0028*g(side*.012,1.686,.0065,.0055)
 z-=front**5*.0023*g(side*.009,1.682,.0038,.0023)
 z-=front**4*.0012*g(side*.018,1.684,.0030,.006)
z+=front**4*.0011*g(-.044,1.66,.024,.025)
# Broader soft-tissue jowls and subtly lowered chin characteristic of age.
x*=1+.09*np.exp(-((y-1.642)/.029)**2)*np.maximum(0,np.cos(t))**.6
# Actual scan profile around neck is retained; gently broaden shoulders at the bottom.
y+=.005*np.exp(-((y-1.573)/.024)**2);P=np.stack([x,y,z],-1);U=np.stack([(t+np.pi)/(2*np.pi),rr/64],-1)
# Export a first look without surface patches. Build a clean indexed mesh.
V=[];UV=[];FF=[];CC=[];tag=[]
def grid(p,uv,color,kind,mask=None):
 k0=sum(len(a) for a in V);h,w=p.shape[:2];p=p.reshape(-1,3);uv=uv.reshape(-1,2);i,j=np.meshgrid(np.arange(h-1),np.arange(w-1),indexing='ij');a=(i*w+j).ravel();f=np.stack([a,a+w,a+w+1,a,a+w+1,a+1],1).reshape(-1,3)
 if mask is not None:f=f[~mask.ravel()[f].any(1)]
 xyz=p[f];cross=np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]);ref=xyz.mean(1)-np.array([0,1.69,-.008]);ref[:,1]*=.2
 if np.median((cross*ref).sum(1))<0:f=f[:,::-1]
 V.append(p);UV.append(uv);FF.append(f+k0);CC.append(np.tile(color,(len(p),1)));tag.extend([kind]*len(p))
grid(P,U,[.53,.53,.53],'skin')
# Full spherical eyeballs, separate clay material. The skin controls the aperture.
for cx,cy,cz in centers:
 phi,theta=np.meshgrid(np.linspace(0,np.pi,65),np.linspace(-np.pi,np.pi,129),indexing='ij')
 p=np.stack([cx+R*np.sin(phi)*np.sin(theta),cy+R*np.cos(phi),cz+R*np.sin(phi)*np.cos(theta)],-1)
 grid(p,np.stack([(theta+np.pi)/(2*np.pi),phi/np.pi],-1),[.47,.47,.47],'eye')
v=np.concatenate(V).astype('f4');uv=np.concatenate(UV).astype('f4');f=np.concatenate(FF).astype('u4');c=np.concatenate(CC).astype('f4');tag=np.array(tag);p=v[f];cross=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]);valid=np.linalg.norm(cross,axis=1)>1e-12;f=f[valid];cross=cross[valid];n=np.zeros_like(v)
# orient each triangle using outward reference, with ears' side orientation and eye/front patches
cent=v[f].mean(1);ref=cent-np.array([0,1.69,-.014]);ref[:,1]*=.45; dot=(cross*ref).sum(1)
for k in range(3):np.add.at(n,f[:,k],cross)
n/=np.maximum(np.linalg.norm(n,axis=1,keepdims=True),1e-10);used,inv=np.unique(f,return_inverse=True);v,n,uv,c,tag=[a[used] for a in (v,n,uv,c,tag)];f=inv.reshape(-1,3).astype('u4');np.savez(D/'head.npz',v=v,n=n,uv=uv,f=f,c=c,tag=tag)
# Export actual head with inherited full skeleton and animation. Keep required data only.
raw=(S/'rig_template.glb').read_bytes();L=struct.unpack_from('<I',raw,12)[0];old=json.loads(raw[20:20+L]);bin0=memoryview(raw)[28+L:];doc={k:copy.deepcopy(old[k]) for k in ['asset','scene','scenes','nodes','skins','animations']};doc.update(buffers=[{'byteLength':0}],bufferViews=[],accessors=[],meshes=[],materials=[{'name':'Anatomy clay','pbrMetallicRoughness':{'baseColorFactor':[.53,.53,.53,1],'metallicFactor':0,'roughnessFactor':.8},'doubleSided':True},{'name':'Eye clay','pbrMetallicRoughness':{'baseColorFactor':[.33,.33,.33,1],'metallicFactor':0,'roughnessFactor':.5},'doubleSided':True}]);data=bytearray()
def view(bb,target=None):
 data.extend(b'\0'*((-len(data))%4));o=len(data);data.extend(bb);z={'buffer':0,'byteOffset':o,'byteLength':len(bb)}
 if target:z['target']=target
 doc['bufferViews'].append(z);return len(doc['bufferViews'])-1
cache={}
def copyacc(i):
 if i in cache:return cache[i]
 a=copy.deepcopy(old['accessors'][i]);b=old['bufferViews'][a['bufferView']];o=b.get('byteOffset',0);a['bufferView']=view(bin0[o:o+b['byteLength']],b.get('target'));doc['accessors'].append(a);cache[i]=len(doc['accessors'])-1;return cache[i]
for sk in doc['skins']:sk['inverseBindMatrices']=copyacc(sk['inverseBindMatrices'])
for anim in doc['animations']:
 for s in anim['samplers']:s['input']=copyacc(s['input']);s['output']=copyacc(s['output'])
def add(arr,typ,ct,target):
 arr=np.ascontiguousarray(arr);a={'bufferView':view(arr.tobytes(),target),'componentType':ct,'count':len(arr),'type':typ}
 if typ=='VEC3' or target==34963:a.update(min=np.atleast_1d(arr.min(0)).tolist(),max=np.atleast_1d(arr.max(0)).tolist())
 doc['accessors'].append(a);return len(doc['accessors'])-1
names=[doc['nodes'][i].get('name') for i in doc['skins'][0]['joints']];h=names.index('Head');ne=names.index('Neck');J=np.zeros((len(v),4),'u2');J[:,0]=h;J[:,1]=ne;w=np.clip((v[:,1]-1.49)/.08,0,1);w[tag=='eye']=1;W=np.zeros((len(v),4),'f4');W[:,0]=w;W[:,1]=1-w;assert np.allclose(W.sum(1),1)
att={'POSITION':add(v,'VEC3',5126,34962),'NORMAL':add(n,'VEC3',5126,34962),'TEXCOORD_0':add(uv,'VEC2',5126,34962),'JOINTS_0':add(J,'VEC4',5123,34962),'WEIGHTS_0':add(W,'VEC4',5126,34962)};pr=[]
for mi,m in [(0,tag!='eye'),(1,tag=='eye')]:
 ff=f[m[f].all(1)];
 if not len(ff):continue
 pr.append({'attributes':att,'indices':add(ff.ravel(),'SCALAR',5125,34963),'material':mi,'mode':4})
doc['meshes']=[{'name':'V24 anatomical head study','primitives':pr}];data.extend(b'\0'*((-len(data))%4));doc['buffers'][0]['byteLength']=len(data);j=json.dumps(doc,separators=(',',':')).encode();j+=b' '*((-len(j))%4);out=D/'ded_moroz_v24_head_rig.glb';out.write_bytes(struct.pack('<4sII',b'glTF',2,28+len(j)+len(data))+struct.pack('<I4s',len(j),b'JSON')+j+struct.pack('<I4s',len(data),b'BIN\0')+data)
print('HEAD',len(v),len(f),len(names),len(doc['animations']),out.stat().st_size,flush=True)
